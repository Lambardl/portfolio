#ifndef COMPLEXE_H
#define COMPLEXE_H


struct complexe{
	int a;//Partie r�elle  
	int b; //Partie imaginaire
};

complexe addition(complexe z1,complexe z2){
	complexe z;
	z.a=z1.a+z2.a;
	z.b=z1.b+z2.b;
	return z;
}

complexe soustraction(complexe Z1,complexe Z2){
	complexe Z;
	Z.a=Z1.a-Z2.a;
	Z.b=Z1.b-Z2.b;
	return Z;
}

#endif
