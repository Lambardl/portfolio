#include <iostream>
#include "complexe.h"
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void Nmbre_complex_addition(){
	complexe z1,z2,z;
	cout<<"Entrez Z1"<<endl;
	cout<<" a = ";
	cin>>z1.a;
	cout<<" b =  ";
	cin>>z1.b;
	cout<<"Entrez Z2"<<endl;
	cout<<" a = ";
	cin>>z2.a;
	cout<<" b = ";
	cin>>z2.b;
	z=addition(z1,z2);
	cout<<" Z1 + Z2 = "<<z.a<<" + "<<z.b<<"i"<<endl;
	 
}

void Nmbre_complex_soustraction(){
	complexe Z1,Z2,Z;
	cout<<"Entrez Z1"<<endl;
	cout<<" a = ";
	cin>>Z1.a;
	cout<<" b = ";
	cin>>Z1.b;
	cout<<"Entrez Z2"<<endl;
	cout<<" a = ";
	cin>>Z2.a;
	cout<<" b = ";
	cin>>Z2.b;
	Z=soustraction(Z1,Z2);
	cout<<" Z1 - Z2 = "<<Z.a<<" - "<<Z.b<<"i"<<endl;
}




void Menu_principal(){
	char choix;
	do{
		cout<<"MENU"<<endl;
		cout<<"1-Addition de deux nombres complexes"<<endl;
		cout<<"2-Soustraction de deux nombres complexes"<<endl;
		cout<<"3-SORTIR"<<endl;
		cin>>choix;
		switch(choix){
			case'1':
				Nmbre_complex_addition();
				break;
			
			case'2':
				Nmbre_complex_soustraction();
				break;
			
			default:
				choix='3';
			
							
		}
	}while((choix!='3'));
}


int main(int argc, char** argv) {
	
	Menu_principal();

	return 0;
}
