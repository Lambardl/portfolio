#include <iostream>
#include <fstream>
using namespace std;
int choix;
char reponse='N';
int n=0;
int pos=-1;

typedef struct Etudiant Etudiant;
struct Etudiant{
	string nom, prenom;
	int age;
	string matricule;
	char sexe;
};


Etudiant Tab[10];

void Lecture(Etudiant &E){
	cout<<"Entrez les informations : "<<endl;
	cout<<"Nom: "<<endl;
	cin>>E.nom;
	cout<<"Prenom: "<<endl;
	cin>>E.prenom;
	cout<<"Age: "<<endl;
	cin>>E.age;
	cout<<"Sexe: "<<endl;
	cin>>E.sexe;
	cout<<"Matricule: "<<endl;
	cin>>E.matricule;
}


void Afficher(Etudiant E){
	cout<<"Les informations sont : "<<endl;
	cout<<"Matricule: "<<E.matricule<<endl;
	cout<<"Nom: "<<E.nom<<endl;
	cout<<"Prenom: "<<E.prenom<<endl;
	cout<<"Age: "<<E.age<<endl;
	cout<<"Sexe: "<<E.sexe<<endl;

}


void Menu(){
	system("cls");
	
	cout<<"******************************"<<endl;
	cout<<"***Mon Programme***"<<endl;
	cout<<"******************************"<<endl<<endl;
	cout<<" 1: Ajouter un etudiant  "<<endl;
	cout<<" 2: Afficher un etudiant  "<<endl;
	cout<<" 3: Afficher tous les etudiants  "<<endl;
	cout<<" 4: Sauvegarder "<<endl;
	cout<<" 5: Restaurer "<<endl;
	cout<<" 6: Quitter "<<endl;
	cin>>choix;
}

void Sauvegarde(){
	string fichier="test.txt";
	ofstream f("test.txt");
	if(!f.is_open()){
		cout<<"Impossible d'ouvrir le fichier en ecriture"<<endl;
	}else{
		for(int i=0;i<n;i++){
			f<<Tab[i].matricule<<" "<<Tab[i].nom<<" "<<Tab[i].prenom<<" "<<Tab[i].age<<" "<<Tab[i].sexe<<endl;
		}
	f.close();
	}

}

void Restaurer(){
	n=0;
	ifstream f("test.txt");
	if(!f.is_open()){
		cout<<"Impossible d'ouvrir le fichier en ecriture"<<endl;
	}else{
		while(!f.eof()){
			f>>Tab[n].matricule>>Tab[n].nom>>Tab[n].prenom>>Tab[n].age>>Tab[n].sexe;
			n++;
		}
		f.close();
	}
;
}



/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	Etudiant A;
	while((reponse!='o')&&(reponse!='O')){
		Menu();
		switch(choix){
			case 1 :
			{
				system("cls");
				Lecture(A);
				Tab[n]=A;
				n++;
				
				break;
			}
			
			
			case 2 :
				{
					system("cls");
					cout<<"Entrez le matricule de l'etudiant a afficher : "<<endl;
					cin>>A.matricule;
					for(int i=0;i<n;i++){
						if(Tab[i].matricule==A.matricule){
							pos=i;
							Afficher(Tab[pos]);
							system("Pause");
							break;
						}
				}
				break;
				}
			
		case 3 :
			{
				system("cls");
				cout<<"Tous les etudiants "<<endl;
				for(int i=0;i<n;i++){
					Afficher(Tab[i]);
					cout<<endl;
					system("Pause");
				}
				break;
		    }
				
			
		case 4 :
			{
				Sauvegarde();
				cout<<"Sauvegarde Effectuee "<<endl;
			}
			
		case 5:
			{
				Restaurer();
				cout<<"Restauration effectue ! "<<endl;
			}
			
		case 6 :{
			cout<<"Etes-vous sur de vouloir sortir ?"<<endl;
				cin>>reponse;
				if((reponse=='O')||(reponse=='o')){
					system("exit");
				};
			break;
		}
				
	}
			
}
	return 0;
}
